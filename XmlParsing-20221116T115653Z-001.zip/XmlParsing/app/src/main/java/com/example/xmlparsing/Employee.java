package com.example.xmlparsing;

public class Employee {
    private int id;
    private String name;
    private float salary;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public float getSalary() {
        return salary;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }
    public String toString() {
        return "id="+id+"\n name="+name+"\n salary="+salary;
    }
}
