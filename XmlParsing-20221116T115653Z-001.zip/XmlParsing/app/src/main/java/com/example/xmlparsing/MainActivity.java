package com.example.xmlparsing;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView=findViewById(R.id.listview1);
        List<Employee> employees=null;

        try {
            XmlPullParserHandler parser=new XmlPullParserHandler();
            InputStream is=getApplicationContext().getAssets().open("employees.xml");
            employees=parser.parse(is);
            String name=null;
            Toast.makeText(getApplicationContext(), "Name is:"+name, Toast.LENGTH_SHORT).show();
            ArrayAdapter<Employee> adapter=new ArrayAdapter<Employee>(this, android.R.layout.simple_list_item_1,employees);
            listView.setAdapter(adapter);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}