package com.example.sms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    Button b;
    EditText msg,phn;
    String t1,t2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.button);
        msg=findViewById(R.id.ed_msg);
        phn=findViewById(R.id.ed_phone);


    }

    public void buttonclick(View view) {
        t1=msg.getText().toString();
        t2=phn.getText().toString();
        try {


            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(t1, null, t2, null, null);
            Toast.makeText(this, "SMS SEND", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "SMS NOT SEND", Toast.LENGTH_SHORT).show();
        }
    }
}