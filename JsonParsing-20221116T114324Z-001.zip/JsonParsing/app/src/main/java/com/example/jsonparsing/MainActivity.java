package com.example.jsonparsing;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    String url = "https://run.mocky.io/v3/3dda9839-e476-4512-aa2e-c5c173a0eafd";
    String result;
    String s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView=findViewById(R.id.tv_json);
        new JsonParse().execute();
    }

    public class JsonParse extends AsyncTask<Void,Void,String>{
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {

            super.onPostExecute(s);
            try {
                JSONArray jsonArray=new JSONArray(s);
                StringBuilder newbuilder=new StringBuilder();
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject object=jsonArray.getJSONObject(i);
                    //Log.e("JSON OBJECT",object.toString());
                    //Log.e("JSON OBJECT",object.getString("name"));
                    newbuilder.append(object.getString("name")+"\n");
                    s=newbuilder.toString();
                    //textView.setText(object.getString("favorite-game"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            textView.setText(s);
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL myurl = new URL(url);
                HttpURLConnection urlConnection= (HttpURLConnection) myurl.openConnection();
                InputStreamReader streamReader=new InputStreamReader(urlConnection.getInputStream());
                BufferedReader reader=new BufferedReader(streamReader);
                StringBuilder builder=new StringBuilder();
                String line;
                while ((line=reader.readLine())!=null){
                    builder.append(line);
                }
                result=builder.toString();
                Log.e("TAG-JSONPARSE",builder.toString());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return result;
        }
        }
    }
