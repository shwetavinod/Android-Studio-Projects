package com.example.animation2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button rotate,scale,set,translate,alpha;
    ImageView imageView;
    Animation animTranslate,animRotate,animScale,animAlpha,animSet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rotate=findViewById(R.id.rotate);
        scale=findViewById(R.id.sc);
        set=findViewById(R.id.set);
        translate=findViewById(R.id.translate);
        alpha=findViewById(R.id.alpha);

        imageView=findViewById(R.id.iv);

        rotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animRotate= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.myrotate);
                imageView.startAnimation(animRotate);

            }
        });

        scale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animScale= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.myscale);
                imageView.startAnimation(animScale);

            }
        });

        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animSet= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.myset);
                imageView.startAnimation(animSet);

            }
        });

        translate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animTranslate= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.mytranslate);
                imageView.startAnimation(animTranslate);


            }
        });

        alpha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                animAlpha= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.myalpha);
                imageView.startAnimation(animAlpha);


            }
        });


    }
}