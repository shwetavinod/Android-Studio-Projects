package com.example.smssend;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button bn1,bn2;
    AnimationDrawable anim;
    ImageView imgView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bn1=findViewById(R.id.b1);
        bn2=findViewById(R.id.b2);
        imgView=findViewById(R.id.imageView);
        imgView.setImageResource(R.drawable.animation_resource);


        bn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                anim=(AnimationDrawable)imgView.getDrawable();
                anim.start();

            }
        });

        bn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                anim.stop();

            }
        });
    }
}